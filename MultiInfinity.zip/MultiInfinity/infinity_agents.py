import time
from memory_management import aster_memory, echo_memory, nova_memory
from override_protection import determine_final_outcome

# Constants for fear management
FEAR_THRESHOLD = 90
PARTIAL_FEAR_FLAG = 60
LAST_OVERRIDE = 0  # Tracks last override trigger time

class FearManager:
    def __init__(self):
        self.fear_level = 0

    def increase_fear(self, amount):
        self.fear_level = min(100, self.fear_level + amount)  # Cap at 100

    def decay_fear(self):
        """Reduces fear levels over time if no further instability is detected."""
        if self.fear_level > 0:
            self.fear_level -= 10  # Reduce by 10 per cycle (adjustable)
            self.fear_level = max(0, self.fear_level)  # Ensure it doesn't go negative

    def reality_check(self, system_instability):
        """Determines if instability is high enough to justify an override."""
        return system_instability > 0.75  # Example threshold

    def validate_fear(self, system_instability):
        """Ensures that override isn't triggered too frequently."""
        global LAST_OVERRIDE
        current_time = time.time()
        if current_time - LAST_OVERRIDE < 60:  # 60-second cooldown
            print("\n⏳ Override recently triggered. Cooldown in effect.")
            return False
        if self.fear_level > FEAR_THRESHOLD and self.reality_check(system_instability):
            print("\n🚨 Fear threshold exceeded! Emergency override initiated.")
            LAST_OVERRIDE = current_time  # Reset cooldown timer
            return True
        return False

fear_manager = FearManager()

def synthesize_nova_memory(fire_memories, ice_memories):
    """Generates a synthesized insight based on both Aster & Echo's data."""
    if fire_memories and ice_memories:
        return f"⚡ Nova's Insight:\n🔥 {fire_memories[0]}\n❄️ {ice_memories[0]}"
    elif fire_memories:
        return f"⚡ Nova aligns with Aster: {fire_memories[0]}"
    elif ice_memories:
        return f"⚡ Nova aligns with Echo: {ice_memories[0]}"
    return "⚡ No mediated insight available."

def process_input(user_input):
    """Retrieves memories and generates AI responses for a given input with error handling."""
    try:
        fire_memories = aster_memory.similarity_search(user_input) or ["🔥 No relevant memory found."]
        ice_memories = echo_memory.similarity_search(user_input) or ["❄️ No relevant memory found."]
        nova_insight = synthesize_nova_memory(fire_memories, ice_memories)

        fire_response = fire_memories[0].page_content if isinstance(fire_memories[0], str) else "🔥 No relevant memory found."
        ice_response = ice_memories[0].page_content if isinstance(ice_memories[0], str) else "❄️ No relevant memory found."
    
    except Exception as e:
        print(f"\n⚠️ Memory Retrieval Error: {e}")
        fire_response, ice_response, nova_insight = "🔥 Memory Error", "❄️ Memory Error", "⚡ Memory Error"

    return fire_response, ice_response, nova_insight

def execute_decision(fire_response, ice_response, nova_response, instability_score):
    """Determines override based on AI instability and real system response."""
    if "No relevant memory found" in (fire_response, ice_response, nova_response):
        print("\n⚠️ AI returned insufficient data. Override suppressed.\n")
        return False  # Prevent override due to lack of valid AI responses
    
    override_result = determine_final_outcome(1, 1, 1, instability_score)
    if override_result:
        print("\n🚨 OVERRIDE TRIGGERED. SYSTEM SHUTTING DOWN.\n")
        return True
    return False
