from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
from infinity_agents import process_input, execute_decision

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/')
def index():
    return render_template('index.html')

@socketio.on('user_input')
def handle_input(data):
    user_message = data['message']
    fire_response, ice_response, mediated_response = process_input(user_message)
    
    override_triggered = execute_decision(fire_response, ice_response, mediated_response, 0.3)
    
    response_data = {
        "aster": fire_response,
        "echo": ice_response,
        "nova": mediated_response,
        "override": override_triggered
    }
    
    emit('ai_response', response_data, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True)