const socket = io();

function sendMessage() {
    const userInput = document.getElementById("user-input");
    const message = userInput.value.trim();
    if (!message) return;

    appendMessage("You", message);
    socket.emit("user_input", { message });
    userInput.value = "";
}

socket.on("ai_response", function(data) {
    appendMessage("🔥 Aster", data.aster);
    appendMessage("❄️ Echo", data.echo);
    appendMessage("⚡ Nova", data.nova);
    
    if (data.override) {
        appendMessage("🚨 SYSTEM", "Override Triggered! Shutting Down...");
    }
});

function appendMessage(sender, message) {
    const chatBox = document.getElementById("chat-box");
    const newMessage = document.createElement("div");

    newMessage.innerHTML = `<strong>${sender}:</strong> ${message}`;
    newMessage.style.opacity = "0";
    newMessage.style.transition = "opacity 0.3s ease-in-out";

    chatBox.appendChild(newMessage);
    setTimeout(() => (newMessage.style.opacity = "1"), 50);
    chatBox.scrollTop = chatBox.scrollHeight;
}