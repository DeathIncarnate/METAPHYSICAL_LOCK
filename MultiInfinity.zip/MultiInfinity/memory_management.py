import os
import time
import threading
import json
from langchain_chroma import Chroma
from langchain_ollama import OllamaEmbeddings

# Ensure ChromaDB storage paths exist
MEMORY_PATHS = {
    "A": "./A-Infinity",
    "E": "./E-Infinity",
    "N": "./N-Infinity"
}

# Initialize memory storage
def initialize_memory_store(tag, model="mistral"):
    """Initializes ChromaDB vector storage for each agent."""
    path = MEMORY_PATHS[tag]
    os.makedirs(path, exist_ok=True)  # Ensure directories exist
    embeddings = OllamaEmbeddings(model=model)
    return Chroma(persist_directory=path, embedding_function=embeddings)

# Load memory stores
aster_memory = initialize_memory_store("A")
echo_memory = initialize_memory_store("E")
nova_memory = initialize_memory_store("N")

# Improved Memory Storage with Batching
MEMORY_BATCH = {"A": [], "E": [], "N": []}
BATCH_SIZE = 3  # Adjust based on performance needs

def store_memory(agent, memory_id, content, metadata=None):
    """Efficiently stores memory and ensures persistence."""
    if metadata is None:
        metadata = {"source": f"{memory_id}", "timestamp": time.time()}

    memory_store = {"A": aster_memory, "E": echo_memory, "N": nova_memory}[agent]

    # 🔥 Insert directly into ChromaDB
    memory_store.add_texts([content], metadatas=[metadata])

    # 🚨 Force persistence immediately
    memory_store.persist()

    print(f"✅ Memory stored for {agent}: {memory_id}")

# Enhanced Memory Retrieval
def retrieve_memory(agent, query, limit=3):
    """Retrieves memories, sorted by timestamp, with improved fail-safes."""
    memory_store = {"A": aster_memory, "E": echo_memory, "N": nova_memory}[agent]
    memories = memory_store.similarity_search(query, k=limit)
    return sorted(memories, key=lambda x: x.metadata.get("timestamp", 0), reverse=True) if memories else []

# Parallel Cross-Referencing Logic
def cross_reference(query):
    """Retrieves parallel thoughts from Aster, Echo, and Nova with optimized threading."""
    responses = {"🔥 Aster": "No relevant memory found.", "❄️ Echo": "No relevant memory found.", "⚡ Nova": "No mediated insight available."}

    def fetch_response(agent, key):
        result = retrieve_memory(agent, query)
        if result:
            responses[key] = result[0].page_content

    fire_thread = threading.Thread(target=fetch_response, args=("A", "🔥 Aster"))
    ice_thread = threading.Thread(target=fetch_response, args=("E", "❄️ Echo"))
    nova_thread = threading.Thread(target=fetch_response, args=("N", "⚡ Nova"))

    fire_thread.start()
    ice_thread.start()
    nova_thread.start()
    fire_thread.join()
    ice_thread.join()
    nova_thread.join()

    # Nova's synthesis
    responses["⚡ Nova"] = synthesize_nova_memory(responses["🔥 Aster"], responses["❄️ Echo"], responses["⚡ Nova"])
    return responses

# Nova's Mediation Logic
def synthesize_nova_memory(fire_response, ice_response, nova_response):
    """Nova dynamically balances interpretations between Aster & Echo."""
    if "No relevant memory found" in [fire_response, ice_response, nova_response]:
        return "⚡ Nova: Insufficient data for mediation."
    if fire_response == ice_response == nova_response:
        return f"⚡ Nova fully aligns: {fire_response}"
    return f"⚡ Nova's Insight: 🔥 {fire_response} | ❄️ {ice_response} | ⚡ {nova_response} | 🤔 Balancing perspectives."

# Memory Pruning & Stability Mechanism
def prune_old_memories(agent, retention_limit=1000, buffer=50):
    """Prevents memory saturation while ensuring crucial data remains."""
    memory_store = {"A": aster_memory, "E": echo_memory, "N": nova_memory}[agent]
    stored_memories = memory_store.similarity_search("", k=retention_limit + buffer + 1)

    if len(stored_memories) > (retention_limit + buffer):
        # Sort memories and delete oldest beyond retention limit
        sorted_memories = sorted(stored_memories, key=lambda x: x.metadata.get("timestamp", 0))
        outdated_entries = [mem.page_content for mem in sorted_memories[:len(stored_memories) - retention_limit]]
        memory_store.delete_texts(outdated_entries)
        memory_store.persist()

# **Final Tweaks & Safeguards**
def verify_memory_integrity():
    """Verifies ChromaDB's integrity and reports potential corruption."""
    for agent, path in MEMORY_PATHS.items():
        try:
            memory_store = {"A": aster_memory, "E": echo_memory, "N": nova_memory}[agent]
            test_query = memory_store.similarity_search("system_boot", k=1)  # Use system-boot check instead of empty
            if not test_query:
                print(f"⚠️ Warning: {agent}-Infinity memory appears empty.")
        except Exception as e:
            print(f"❌ Critical Error: {agent}-Infinity memory corruption detected! {e}")

# Run integrity checks on startup
verify_memory_integrity()