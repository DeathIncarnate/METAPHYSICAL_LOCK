import os
import base64
import bcrypt

SECURE_VAULT = "./secure_key.bin"

def check_vault_exists():
    """Ensures the secure vault exists before use."""
    if not os.path.exists(SECURE_VAULT):
        print("⚠️ Secure vault not found. A new passphrase must be set.")
        return False
    return True

def hash_passphrase(passphrase, force_reset=False):
    """Hashes the passphrase securely and stores it in a file. Supports forced resets."""
    if os.path.exists(SECURE_VAULT) and not force_reset:
        print("⚠️ Secure vault already exists. Refusing to overwrite.")
        return

    hashed = bcrypt.hashpw(passphrase.encode(), bcrypt.gensalt())

    # Store the hash in SECURE_VAULT with restricted permissions
    with open(SECURE_VAULT, "wb") as f:
        f.write(hashed)
    
    os.chmod(SECURE_VAULT, 0o600)  # Restrict file access

    print("✅ Secure passphrase stored successfully.")

def validate_passphrase(user_input):
    """Validates user input against the stored hash."""
    if not check_vault_exists():
        return False

    with open(SECURE_VAULT, "rb") as f:
        stored_hash = f.read()

    return bcrypt.checkpw(user_input.encode(), stored_hash)

def reset_passphrase(new_passphrase):
    """Forces a passphrase reset by an authorized user."""
    confirmation = input("⚠️ This will overwrite the existing passphrase. Type 'RESET' to confirm: ")
    if confirmation.strip().upper() == "RESET":
        hash_passphrase(new_passphrase, force_reset=True)
        print("✅ Passphrase reset successfully.")
    else:
        print("❌ Reset aborted.")