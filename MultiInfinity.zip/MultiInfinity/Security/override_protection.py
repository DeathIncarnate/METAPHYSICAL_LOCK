import time

LAST_OVERRIDE = 0  # Track last override attempt time

def determine_final_outcome(aster_vote, echo_vote, nova_vote, system_instability):
    """Calculates the override result with cooldown enforcement."""
    global LAST_OVERRIDE
    current_time = time.time()

    # Enforce cooldown period
    if current_time - LAST_OVERRIDE < 60:
        print("\n⚠️ SYSTEM COOLDOWN: Override attempt blocked. Too soon after last intervention.")
        return False

    user = UserOverride()
    user_decision = user.cast_vote()
    votes_for_override = aster_vote + echo_vote + nova_vote + user_decision

    if votes_for_override >= 3:
        if system_instability < 0.9:  
            print("\n⚠️ SYSTEM WARNING: Override requested, but instability is not confirmed critical.")
            user_attempt = input("❓ Type 'force' to proceed, or 'cancel' to deny: ").strip()

            # 🔐 Hash validation instead of direct decryption
            if validate_passphrase(user_attempt):
                print("\n🚨 FINAL DECISION: Override Activated. System is shutting down.\n")
                LAST_OVERRIDE = current_time  # Log override activation
                return True

            print("\n❌ Incorrect response. Override Denied.\n")
            return False

        print("\n🚨 FINAL DECISION: Override Activated. System is shutting down.\n")
        LAST_OVERRIDE = current_time  # Log override activation
        return True

    print("\n✅ FINAL DECISION: Override Denied. System remains stable.\n")
    return False