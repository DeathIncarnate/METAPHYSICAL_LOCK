class UserOverride:
    def __init__(self):
        self.weight = 2  # User’s vote counts as double

    def cast_vote(self):
        """Prompts the user to vote on override activation."""
        while True:
            user_input = input("\n🚨 SYSTEM ALERT: Override Requested. Approve or Deny? (approve/deny): ").strip().lower()
            if user_input in ["approve", "deny"]:
                return self.weight if user_input == "approve" else 0
            print("❌ Invalid input. Please type 'approve' or 'deny'.")