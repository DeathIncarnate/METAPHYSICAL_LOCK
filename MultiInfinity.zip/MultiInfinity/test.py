from memory_management import store_memory, aster_memory

store_memory("A", "test-memory", "This is a test message.", {"source": "ManualTest"})