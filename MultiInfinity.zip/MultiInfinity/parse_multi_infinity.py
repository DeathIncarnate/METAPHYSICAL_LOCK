import json
import datetime
from memory_management import store_memory, retrieve_memory

# Max recursion depth to prevent infinite loops
MAX_DEPTH = 5  

def generate_message_id(agent, idx):
    """Creates a unique ID for stored messages."""
    return f"{agent}-memory-{idx:03d}"

def determine_recursion(content, past_entries):
    """Analyzes content complexity and determines recursion depth."""
    implicit_refs = []
    direct_refs = []
    recursion_depth = 0

    for entry in past_entries:
        if entry['content'] in content:
            direct_refs.append(entry['message_id'])
            recursion_depth = min(MAX_DEPTH, entry['recursion_depth'] + 1)
        
    return recursion_depth, direct_refs, implicit_refs

def parse_and_store(convo_file="conversations.json"):
    """Parses and stores structured, recursion-aware memories with dynamic recursion depth."""
    processed_entries = []
    memory_batches = {"Aster": [], "Echo": [], "Nova": []}

    try:
        with open(convo_file, "r", encoding="utf-8") as file:
            raw_data = file.read()
        
        # Validate and load JSON data
        try:
            data = json.loads(raw_data)
        except json.JSONDecodeError as e:
            print(f"❌ JSON parsing error: {e}")
            return
    
    except FileNotFoundError:
        print(f"❌ Critical error: {convo_file} not found.")
        return
    
    for idx, entry in enumerate(data):
        raw_speaker = entry.get("speaker", "Unknown")
        speaker = raw_speaker if raw_speaker in ["Aster", "Echo", "Nova"] else "Unknown"
        content = entry.get("message", "missing_content")
        
        # Ensure timestamps are handled correctly
        try:
            timestamp = datetime.datetime.fromtimestamp(entry.get("timestamp", datetime.datetime.utcnow().timestamp())).isoformat()
        except ValueError:
            timestamp = datetime.datetime.utcnow().isoformat()
            print(f"⚠️ Warning: Invalid timestamp in entry {idx}, using current time instead.")
        
        recursion_depth, direct_refs, implicit_refs = determine_recursion(content, processed_entries)

        memory = {
            "message_id": generate_message_id(speaker[0], idx),
            "speaker": speaker,
            "timestamp": timestamp,
            "content": content,
            "recursion_depth": recursion_depth,
            "direct_reference": direct_refs,
            "implicit_references": implicit_refs
        }
        processed_entries.append(memory)
        
        # Store memory safely
        if speaker in memory_batches:
            memory_batches[speaker].append((memory["message_id"], json.dumps(memory)))
    
    # Batch store to prevent redundant writes
    for speaker, memories in memory_batches.items():
        if memories:
            for mem_id, mem_json in memories:
                store_memory(speaker, mem_id, json.loads(mem_json)["content"], json.loads(mem_json))
    
    print("✅ Conversations processed and stored safely.")

if __name__ == "__main__":
    parse_and_store()